package com.controller;

import java.io.IOException;
import java.sql.Connection;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.ConnectionFactory.ConnectionFactory;
import com.Dao.TxnHistoryDao;
@WebServlet("/txn")
public class Launch9 extends HttpServlet{
	
	Connection con = ConnectionFactory.getCon();
	TxnHistoryDao txnDao = new TxnHistoryDao();
	@Override
	protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		String id = req.getParameter("uid");
		req.getSession().setAttribute("check", id);
		req.getSession().setAttribute("txnl", txnDao.readTxn(con, id));
		resp.sendRedirect("txnhistory.jsp");
	}

}
