package com.controller;

import java.io.*;
import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

@WebServlet("/SendOtpServlet")
public class SendOtpServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException {
        String mobile = request.getParameter("mobile");
        // OTP send logic here (hardcoded OTP for testing)
        String otp = "123456";

        // Here you can integrate actual SMS API like Fast2SMS, Twilio, etc.

        // Response
        response.setContentType("text/plain");
        response.getWriter().write("OTP sent successfully to " + mobile);
    }
}
