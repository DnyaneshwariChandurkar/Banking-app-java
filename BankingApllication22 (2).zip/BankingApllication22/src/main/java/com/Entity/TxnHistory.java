package com.Entity;

public class TxnHistory {

	String acno;
	String amount;
	String tStatus;
	String datetime;
	String availBal;
	public String getAcno() {
		return acno;
	}
	@Override
	public String toString() {
		return "TxnHistory [acno=" + acno + ", amount=" + amount + ", tStatus=" + tStatus + ", datetime=" + datetime
				+ ", availBal=" + availBal + "]";
	}
	public void setAcno(String acno) {
		this.acno = acno;
	}
	public String getAmount() {
		return amount;
	}
	public void setAmount(String amount) {
		this.amount = amount;
	}
	public String gettStatus() {
		return tStatus;
	}
	public void settStatus(String tStatus) {
		this.tStatus = tStatus;
	}
	public String getDatetime() {
		return datetime;
	}
	public void setDatetime(String datetime) {
		this.datetime = datetime;
	}
	public String getAvailBal() {
		return availBal;
	}
	public void setAvailBal(String availBal) {
		this.availBal = availBal;
	}
	
	
}
