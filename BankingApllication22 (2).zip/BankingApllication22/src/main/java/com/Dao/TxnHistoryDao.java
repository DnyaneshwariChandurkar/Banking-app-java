package com.Dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import com.Entity.TxnHistory;

public class TxnHistoryDao {
	
	String result="";
	public String insertTxn(Connection con, String uid, String am, String tStatus)
	{
		try
		{
			//read account no
			String acno="";
			String bal="";
			String sql1 = "select * from accouunt where userid=?";
			PreparedStatement ps = con.prepareStatement(sql1);
			ps.setString(1, uid);
			ResultSet rs = ps.executeQuery();
			while(rs.next())
			{
				acno=rs.getString("acno");
				bal = rs.getString("bal");
			}
			String date = LocalDate.now().toString();
			
			
			//inserting into txnhistory table
			
			String sql2="insert into txnhistory values(?,?,?,?,?)";
			PreparedStatement ps2 = con.prepareStatement(sql2);
			ps2.setString(1, acno);
			ps2.setString(2, am);
			ps2.setString(3, tStatus);
			ps2.setString(4, date);
			ps2.setString(5, bal);
			
			int i = ps2.executeUpdate();
			
			if(i==1)
			{
				result="inserted";
			}
			else
			{
				result="failed";
			}
			
		}
		catch (Exception e) {
			result="failed";
		}
		finally
		{
			return result;
		}
	}
	
	public List<TxnHistory> readTxn(Connection con, String uid)
	{
		List<TxnHistory> ltxn = new ArrayList<TxnHistory>();
		try
		{
			//read account no
			String acno="";
			String sql1 = "select * from accouunt where userid=?";
			PreparedStatement ps = con.prepareStatement(sql1);
			ps.setString(1, uid);
			ResultSet rs = ps.executeQuery();
			while(rs.next())
			{
				acno=rs.getString("acno");
			}
			
			
			
			
			//read txn
			String sql2 = "select * from txnhistory where acno=?";
			PreparedStatement ps2 = con.prepareStatement(sql2);
			ps2.setString(1, acno);
			ResultSet rs1 = ps2.executeQuery();
			while(rs1.next())
			{
				TxnHistory txn = new TxnHistory();
				txn.setAcno(rs1.getString(1));
				txn.setAmount(rs1.getString(2));
				txn.settStatus(rs1.getString(3));
				txn.setDatetime(rs1.getString(4));
				txn.setAvailBal(rs1.getString(5));
				ltxn.add(txn);
				
			}
			
			
			
		}
		catch (Exception e) {
			// TODO: handle exception
		}
		finally
		{
			return ltxn;
		}
	}

}
